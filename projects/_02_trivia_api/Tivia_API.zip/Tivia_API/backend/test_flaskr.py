import os
import unittest
import json
from flask_sqlalchemy import SQLAlchemy

from flaskr import create_app
from models import setup_db, Question, Category


class TriviaTestCase(unittest.TestCase):
    """This class represents the trivia test case"""

    def setUp(self):
        """Define test variables and initialize app."""
        self.app = create_app()
        self.client = self.app.test_client
        self.database_name = "trivia_test"
        self.database_path = "postgresql://{}/{}".format('postgres:123@localhost:5432', self.database_name)
        setup_db(self.app, self.database_path)

        self.sample_question = {
            'question': 'Where are the pyramids?',
            'answer': 'Egypt',
            'category': 1,
            'difficulty': 2
        }
        self.sample_question2 = {
            'question': 'Where are is USA?',
            'answer': 'North America',
            'category': 1,
            'difficulty': 2
        }

        self.sample_question_invalid = {
            'questionnn': 'Where are the pyramids?',
            'answer': 'Egypt',
            'category': 1,
            'difficulty': 2
        }

        self.sample_category = {
            'category' : "Geography"
        }

        self.sample_category_invalid = {
            'categoryyyyy' : "Geography"
        }

        # binds the app to the current context
        with self.app.app_context():
            self.db = SQLAlchemy()
            self.db.init_app(self.app)
            self.db.drop_all()
            # create all tables
            self.db.create_all()
    
    def tearDown(self):
        """Executed after each test"""
        with self.app.app_context():
            sql_str = 'DROP TABLE IF EXISTS categories;'
            self.db.engine.execute(sql_str)
            sql_str = 'DROP TABLE IF EXISTS questions;'
            self.db.engine.execute(sql_str)
        pass

    """
    TODO
    Write at least one test for each test for successful operation and for expected errors.
    """

    def test_root(self):
        result = self.client().get("/")
        self.assertEqual(result.status_code, 301)

    def test_get_all_categories(self):
        result = self.client().get('/categories')
        data = json.loads(result.data)
        self.assertEqual(result.status_code, 200)

    def test_get_all_categories_empty(self):
        result = self.client().get('/categories')
        data = json.loads(result.data)
        self.assertEqual(data['Message'], 'database empty')
        self.assertEqual(result.status_code, 200)

    def test_get_all_questions(self):
        result = self.client().get('/questions')
        data = json.loads(result.data)
        self.assertEqual(result.status_code, 200)

    def test_get_all_questions_empty(self):
        result = self.client().get('/questions')
        data = json.loads(result.data)
        self.assertEqual(result.status_code, 200)

    def test_add_category(self):
        result = self.client().post('/categories', data=json.dumps(self.sample_category), content_type='application/json')
        data = json.loads(result.data)
        self.assertEqual(result.status_code, 200)

    def test_add_category_invalid(self):
        result = self.client().post('/categories', data=json.dumps(self.sample_category_invalid), content_type='application/json')
        data = json.loads(result.data)
        self.assertEqual(result.status_code, 400)

    def test_add_question(self):
        result = self.client().post('/questions', data=json.dumps(self.sample_question), content_type='application/json')
        data = json.loads(result.data)
        self.assertEqual(result.status_code, 200)

    def test_add_question_invalid(self):
        result = self.client().post('/questions', data=json.dumps(self.sample_question_invalid), content_type='application/json')
        data = json.loads(result.data)
        self.assertEqual(result.status_code, 400)

    def test_delete_question_success(self):
        self.client().post('/categories', data=json.dumps(self.sample_category), content_type='application/json')
        self.client().post('/questions', data=json.dumps(self.sample_question), content_type='application/json')
        result = self.client().delete('/questions/1')
        data = json.loads(result.data)
        print(data)
        self.assertEqual(result.status_code, 200)

    def test_search_questions_bycategory_category_not_exist(self):
        result = self.client().get('/categories/9999/questions')
        data = json.loads(result.data)
        self.assertEqual(result.status_code, 404)
    
    def test_search_questions_bycategory_category_success(self):
        self.client().post('/categories', data=json.dumps(self.sample_category), content_type='application/json')
        self.client().post('/questions', data=json.dumps(self.sample_question), content_type='application/json')
        result = self.client().get('/categories/1/questions')
        data = json.loads(result.data)
        self.assertEqual(result.status_code, 200)

    def test_search_question_search_term(self):
        self.client().post('/categories', data=json.dumps(self.sample_category), content_type='application/json')
        self.client().post('/questions', data=json.dumps(self.sample_question), content_type='application/json')
        result = self.client().post('/questions/search', data=json.dumps({'searchTerm':'pyramids'}), content_type='application/json')
        data = json.loads(result.data)
        print(data)
        self.assertEqual(result.status_code, 200)


    def test_get_quiz_question_success(self):
        self.client().post('/categories', data=json.dumps(self.sample_category), content_type='application/json')
        self.client().post('/questions', data=json.dumps(self.sample_question), content_type='application/json')
        self.client().post('/questions', data=json.dumps(self.sample_question2), content_type='application/json')
        quiz_data = {
            'previous_questions' : [0,1,2],
            'quiz_category' : {'id':1, 'type' : 'Geography'}
        }
        result = self.client().post('/quizzes', data=json.dumps(quiz_data), content_type='application/json')
        data = json.loads(result.data)
        self.assertEqual(result.status_code, 200)

    def test_get_quiz_question_Bad_request(self):
        quiz_data = {
            'previous_questions' : [0,1,2],
            'quiz_category' : {'id':1, 'type' : 'Geography'}
        }
        result = self.client().post('/quizzess', data=json.dumps(quiz_data), content_type='application/json')
        data = json.loads(result.data)
        self.assertEqual(result.status_code, 404)

    def test_get_notfound(self):
        result = self.client().get('/sdhfbsjhf')
        self.assertEqual(result.status_code, 404)

# Make the tests conveniently executable
if __name__ == "__main__":
    unittest.main()