<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="main.css"/>

    </head>
    <body>
        <div>
            <h1 class="center">Trivia Api</h1>
        </div>
        <div>
            <ul>
            <li>
                <h3>Introduction</h3>
                <p>Trivia API is a library for questions and answers classified by category and difficulty levels to implement a Trivia Game</p>
            </li>
            <li>
                <h3>Getting started</h3>
                <ul>
                    <li>
                        <h4>Base URL</h4>
                        <p>This application could run locally as http://localhost:5000 which will bring you this Documentation Page</p>
                    </li>
                    <li>
                        <h4>API Authentication</h4>
                        <p>Requires no authentication</p>
                    </li>
                </ul>
            </li>
            <li>
                <h3>Error Handling</h3>
                <ul>
                    <li>
                        <h4>Messages</h4>
                        <p>Trivia api return errors in json format like this</p>
                        <pre>
     {
         "Success":False,
         "Error": 404,
         "Message":"Not Found!"
     }</pre>
                    </li>
                    <li>
                        <h4>Error Types</h4>
                        <ul>
                            <li>
                                <p>500 : Internal Server Error</p>
                            </li>
                            <li>
                                <p>400 : Bad Request</p>
                            </li>
                            <li>
                                <p>404 : Not Found!</p>
                            </li>
                            <li>
                                <p>405 : Method Not Allowed</p>
                            </li>
                            <li>
                                <p>422 : Unprocessable Entity</p>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li>
                <h3>Endpoints</h3>
                <ul>
                    <li>
                        <h3>Get /categories</h3>
                        <ul>
                            <li>
                                <h4>General</h4>
                                <ul>
                                    <li>
                                        <p>Returns a list of all categories in the game</p>
                                    </li>
                                    <li>
                                        <p>Result : List of category id and type</p>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <h4>Sample : curl http://172.0.0.1:5000/categories</h4>
                                <pre>
     {
         "categories": {
           "1": "Math", 
           "2": "Chemistry", 
           "3": "Physics", 
           "4": "Biology", 
         }
     }
                                </pre>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
            </ul>
            
        </div>
        
    </body>
</html>