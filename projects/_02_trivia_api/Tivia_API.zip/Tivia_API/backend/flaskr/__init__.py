import os
from flask import Flask, request, abort, jsonify, redirect
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import random
from sqlalchemy.sql.expression import func

from models import setup_db, Question, Category, db

QUESTIONS_PER_PAGE = 10

'''
Creating our application and allowing all Cross Origin requests
'''


def create_app(test_config=None):
    app = Flask(__name__)
    setup_db(app)
    CORS(app, resources={r"/api/*": {"origins": "*"}})

    @app.after_request
    def after_request(response):
        response.headers.add('Access-Control-Allow-Headers',
                             'Content-Type, Authorization, True')
        response.headers.add('Access-Control-Allow-Methods',
                             'GET, PATCH, POST, DELETE, OPTIONS')
        return response

    '''
    The root endpoint displays documentation
    '''

    @app.route("/")
    def root():
        return redirect("static/documentation.html", code=301)

    '''
    Endpoint to handle GET requests
    for all available categories returning a dictionary in json format.
    '''

    @app.route("/categories", methods=['GET'])
    def GetAllCategories():
        cat_dic = {}
        cats = Category.query.all()
        if len(cats) == 0:
            return jsonify({'Message': "database empty"})
        for cat in cats:
            cat_dic[cat.id] = cat.type
        return jsonify({'categories': cat_dic})

    '''
    This endpoint allow adding new categories for questions
    '''

    @app.route("/categories", methods=['POST'])
    def AddCategory():
        try:
            category_name = request.get_json()['category']
            category = Category(category_name)
            category.insert()
            return jsonify({
                  'category': category_name,
                  'message': 'added',
                  'state': 'success'
                  })
        except Exception as ex:
            abort(400)

    '''
    Create an endpoint to handle GET requests for questions,
    including pagination (every 10 questions).
    This endpoint should return a list of questions,
    number of total questions, current category, categories.

    TEST: At this point, when you start the application
    you should see questions and categories generated,
    ten questions per page and pagination at the bottom of
    the screen for three pages.
    Clicking on the page numbers should update the questions.
    '''

    @app.route("/questions", methods=['GET'])
    def GetAllQuestions():
        categories = {}
        cats = Category.query.all()
        for category in cats:
            categories[category.id] = category.type
        quest_list = Question.query.all()
        if len(quest_list) == 0:
            return jsonify({"Message": "There are no questions"})
        questions = [question.format() for question in quest_list]
        page = int(request.args.get('page', '0'))
        upper_limit = page * 10
        lower_limit = upper_limit - 10
        return jsonify({
                'questions': questions[lower_limit:upper_limit]
                if page else questions,
                'total_questions': len(questions),
                'categories': categories
            })

    '''
    endpoint to DELETE question using a question ID.
    TEST: When you click the trash icon next to a question,
     the question will be removed.
    This removal will persist in the database and when you refresh the page.
    '''

    @app.route("/questions/<int:quest_id>", methods=["DELETE"])
    def DeleteQuestion(quest_id):
        question = Question.query.get(quest_id)
        question.delete()
        return jsonify({"Deleted": quest_id})

    '''
    endpoint to POST a new question,
    which will require the question and answer text,
    category, and difficulty score.

    TEST: When you submit a question on the "Add" tab,
    the form will clear and the question will appear
    at the end of the last page
    of the questions list in the "List" tab.
    '''

    @app.route('/questions', methods=['POST'])
    def AddQuestion():
        try:
            question = request.get_json()['question']
            answer = request.get_json()['answer']
            category = request.get_json()['category']
            difficulty = request.get_json()['difficulty']
            if not (question and answer and category and difficulty):
                abort(400)
            question_new = Question(question, answer, category, difficulty)
            question_new.insert()
            return jsonify({'question': question_new.format()})
        except Exception as ex:
            abort(400)

    '''
    POST endpoint to get questions based on a search term.
    It should return any questions for whom the search term
    is a substring of the question.

    TEST: Search by any phrase. The questions list will update to include
    only question that include that string within their question.
    Try using the word "title" to start.
    '''

    @app.route("/questions/search", methods=['POST'])
    def SearchQuestion():
        categories = {}
        search_string = request.get_json()['searchTerm']
        for category in Category.query.all():
            categories[category.id] = category.type
            questions = [question.format() for question in db.session.
                         query(Question).filter(Question.
                         question.ilike(f'%{search_string}%'))]
            page = int(request.args.get('page', '0'))
            upper_limit = page * 10
            lower_limit = upper_limit - 10
        return jsonify({
                'questions': questions[lower_limit:upper_limit]
                if page else questions,
                'total_questions': len(questions),
                'categories': categories
            })

    '''
    GET endpoint to get questions based on category.

    TEST: In the "List" tab / main screen, clicking on one of the
    categories in the left column will cause only questions of that
    category to be shown.
    '''

    @app.route("/categories/<int:cat_id>/questions", methods=['GET'])
    def SearchByCategory(cat_id):
        if not cat_id:
            return abort(400, 'Invalid category id')
        if (Category.query.get(cat_id) is None):
            abort(404)
        quests = db.session.query(Question).filter(Question.category == cat_id)
        questions = [question.format() for question in quests]
        return jsonify({
            'questions': questions,
            'total_questions': len(questions),
            'current_category': cat_id
            })

    '''
    POST endpoint to get questions to play the quiz.
    This endpoint should take category and previous question parameters
    and return a random questions within the given category,
    if provided, and that is not one of the previous questions.

    TEST: In the "Play" tab, after a user selects "All" or a category,
    one question at a time is displayed, the user is allowed to answer
    and shown whether they were correct or not.
    '''

    @app.route("/quizzes", methods=['POST'])
    def GetQuizQuestions():
        previous_questions = request.json.get('previous_questions')
        quiz_category = request.json.get('quiz_category')
        if not quiz_category:
            return abort(400, 'Required category missing from request body')
        category_id = int(quiz_category.get('id'))
        questions = Question.query.filter(
            Question.category == category_id,
            ~Question.id.in_(previous_questions))\
            if category_id else Question.\
            query.filter(~Question.id.in_(previous_questions))
        question = questions.order_by(func.random()).first()
        if not question:
            return jsonify({})
        return jsonify({
            'question': question.format()
            })

    '''
    error handlers for all expected errors
    including 500, 400, 404, 405, 422.
    '''

    @app.errorhandler(500)
    def InternalServerError(error):
        return jsonify({
            "Success": False,
            "Error": 500,
            "Message": "Internal Server Error"
            }), 500

    @app.errorhandler(400)
    def BadRequestError(error):
        return jsonify({
            "Success": False,
            "Error": 400,
            "Message": "Bad Request"
            }), 400

    @app.errorhandler(404)
    def NotFoundError(error):
        return jsonify({
            "Success": False,
            "Error": 404,
            "Message": "Not Found!"
            }), 404

    @app.errorhandler(405)
    def MethodNotAllowedError(error):
        return jsonify({
            "Success": False,
            "Error": 405,
            "Message": "Method Not Allowed"
            }), 405

    @app.errorhandler(422)
    def UnprocessableEntryError(error):
        return jsonify({
            "Success": False,
            "Error": 422,
            "Message": "Unprocessable Entity"
            }), 422

    return app